package burp;

import burp.IBurpExtenderCallbacks;

public class Settings {
    private final IBurpExtenderCallbacks callbacks;

    public Settings(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
    }

    private static final String KEY_MODEL = "model";
    private static final String KEY_LANG = "targetLanguage";
    private static final String KEY_AUTO = "autoTranslate";
    private static final String KEY_SKIP_REQRESP = "skipReqResp";
    private static final String KEY_BASEURL = "baseUrl";
    private static final String KEY_PATH    = "completionsPath";
    private static final String KEY_APIHDR  = "apiKeyHeader";
    private static final String KEY_APIHDRP = "apiKeyHeaderPrefix";
    private static final String KEY_CLONE   = "cloneIntoIssues";
    private static final String KEY_PROMPT  = "customPrompt";

    private String apiKeyMem = null;

    public String getApiKey() {
        if (apiKeyMem != null && !apiKeyMem.isEmpty()) return apiKeyMem;
        String env = System.getenv("OPENAI_API_KEY");
        return env != null ? env : "";
    }
    public void setApiKeyMem(String apiKey) { this.apiKeyMem = apiKey == null ? "" : apiKey.trim(); }

    public String getModel() { return getOrDefault(KEY_MODEL, "gpt-4o-mini"); }
    public void setModel(String v) { save(KEY_MODEL, v); }

    public String getTargetLanguage() { return getOrDefault(KEY_LANG, "Polish"); }
    public void setTargetLanguage(String v) { save(KEY_LANG, v); }

    public boolean isAutoTranslate() { return Boolean.parseBoolean(getOrDefault(KEY_AUTO, "true")); }
    public void setAutoTranslate(boolean b) { save(KEY_AUTO, Boolean.toString(b)); }

    public boolean isSkipReqResp() { return Boolean.parseBoolean(getOrDefault(KEY_SKIP_REQRESP, "true")); }
    public void setSkipReqResp(boolean b) { save(KEY_SKIP_REQRESP, Boolean.toString(b)); }

    public String getBaseUrl() { return getOrDefault(KEY_BASEURL, "https://api.openai.com"); }
    public void setBaseUrl(String v) { save(KEY_BASEURL, v); }

    public String getCompletionsPath() { return getOrDefault(KEY_PATH, "/v1/chat/completions"); }
    public void setCompletionsPath(String v) { save(KEY_PATH, v); }

    public String getApiKeyHeader() { return getOrDefault(KEY_APIHDR, "Authorization"); }
    public void setApiKeyHeader(String v) { save(KEY_APIHDR, v); }

    public String getApiKeyHeaderValuePrefix() { return getOrDefault(KEY_APIHDRP, "Bearer "); }
    public void setApiKeyHeaderValuePrefix(String v) { save(KEY_APIHDRP, v); }

    public boolean isCloneIntoIssues() { return Boolean.parseBoolean(getOrDefault(KEY_CLONE, "true")); }
    public void setCloneIntoIssues(boolean b) { save(KEY_CLONE, Boolean.toString(b)); }

    public String getCustomPrompt() {
        String def = "Przetłumacz na polski i zachowaj strukturę sekcji: 'Issue description', 'Remediation', 'References'. " +
                     "Użyj języka technicznego, unikaj nadmiarowych komentarzy. Jeśli to możliwe, dodaj sekcję 'ASVS mapping' z kategorią i poziomem.";
        return getOrDefault(KEY_PROMPT, def);
    }
    public void setCustomPrompt(String v) { save(KEY_PROMPT, v); }

    private String getOrDefault(String key, String def) {
        String v = callbacks.loadExtensionSetting(key);
        return (v == null || v.isEmpty()) ? def : v;
    }
    private void save(String key, String value) {
        callbacks.saveExtensionSetting(key, value == null ? "" : value);
    }
}
