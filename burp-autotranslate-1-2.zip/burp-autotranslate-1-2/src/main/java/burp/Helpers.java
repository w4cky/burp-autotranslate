package burp;

public class Helpers {
    public static String formatIssue(IScanIssue i, boolean skipReqResp) {
        StringBuilder sb = new StringBuilder();
        sb.append("## Issue name: ").append(n(i.getIssueName())).append("\n");
        sb.append("**Severity**: ").append(n(i.getSeverity())).append("; **Confidence**: ").append(n(i.getConfidence())).append("\n\n");
        if (i.getUrl() != null) sb.append("**URL**: ").append(i.getUrl()).append("\n\n");

        String bg = n(i.getIssueBackground());
        String det = n(i.getIssueDetail());
        String rem = n(i.getRemediationDetail());

        if (!bg.isEmpty()) sb.append("### Background\n").append(bg).append("\n\n");
        if (!det.isEmpty()) sb.append("### Issue description\n").append(det).append("\n\n");
        if (!rem.isEmpty()) sb.append("### Remediation\n").append(rem).append("\n\n");

        return sb.toString();
    }
    private static String n(String s) { return s == null ? "" : s; }
}
