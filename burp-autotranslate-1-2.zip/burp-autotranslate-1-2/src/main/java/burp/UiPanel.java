package burp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.datatransfer.StringSelection;

class UiPanel extends JPanel {
    final JTextField apiKey = new JTextField(30);
    final JTextField model = new JTextField("gpt-4o-mini", 16);
    final JTextField language = new JTextField("Polish", 12);
    final JCheckBox auto = new JCheckBox("Auto-translate new issues", true);
    final JCheckBox skipReqResp = new JCheckBox("Skip raw request/response excerpts when sending to API", true);
    final JCheckBox cloneIssues = new JCheckBox("Clone translated into Issues as [PL]", true);

    final JTextField baseUrl = new JTextField("https://api.openai.com", 22);
    final JTextField path = new JTextField("/v1/chat/completions", 22);
    final JTextField apiHdr = new JTextField("Authorization", 16);
    final JTextField apiHdrPrefix = new JTextField("Bearer ", 10);

    final JTextArea prompt = new JTextArea(6, 40);

    final JButton save = new JButton("Save Settings");
    final JButton test = new JButton("Test Translation");
    final JButton copyPlain = new JButton("Copy AdvisoryPL (plain text)");

    final DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Origin", "Translated (PL)"}, 0);
    final JTable table = new JTable(tableModel);

    private final JTextArea advisoryArea = new JTextArea(18, 80);

    private Runnable onSaveCb = () -> {};
    private Runnable onTestCb = () -> {};

    UiPanel(Settings s) {
        super(new BorderLayout(10,10));

        JTabbedPane tabs = new JTabbedPane();

        JPanel settingsPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4); c.gridx=0; c.gridy=0; c.anchor = GridBagConstraints.WEST;

        settingsPanel.add(new JLabel("OpenAI API key (blank = env OPENAI_API_KEY):"), c);
        c.gridx=1; settingsPanel.add(apiKey, c);
        c.gridx=0; c.gridy++ ; settingsPanel.add(new JLabel("Model:"), c);
        c.gridx=1; settingsPanel.add(model, c);
        c.gridx=0; c.gridy++; settingsPanel.add(new JLabel("Target language:"), c);
        c.gridx=1; settingsPanel.add(language, c);
        c.gridx=0; c.gridy++; settingsPanel.add(new JLabel("Base URL:"), c);
        c.gridx=1; settingsPanel.add(baseUrl, c);
        c.gridx=0; c.gridy++; settingsPanel.add(new JLabel("Path:"), c);
        c.gridx=1; settingsPanel.add(path, c);
        c.gridx=0; c.gridy++; settingsPanel.add(new JLabel("API key header:"), c);
        c.gridx=1; settingsPanel.add(apiHdr, c);
        c.gridx=0; c.gridy++; settingsPanel.add(new JLabel("Header value prefix:"), c);
        c.gridx=1; settingsPanel.add(apiHdrPrefix, c);
        c.gridx=0; c.gridy++; settingsPanel.add(auto, c);
        c.gridx=1; settingsPanel.add(skipReqResp, c);
        c.gridx=0; c.gridy++; settingsPanel.add(cloneIssues, c);

        c.gridx=0; c.gridy++; c.gridwidth=2;
        settingsPanel.add(new JLabel("Custom prompt (used before original Advisory):"), c);
        c.gridy++; JScrollPane sp = new JScrollPane(prompt);
        settingsPanel.add(sp, c);
        c.gridy++; c.gridwidth=1;
        settingsPanel.add(save, c);
        c.gridx=1; settingsPanel.add(test, c);

        JPanel tablePanel = new JPanel(new BorderLayout());
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        tablePanel.add(new JScrollPane(table), BorderLayout.CENTER);
        tablePanel.add(settingsPanel, BorderLayout.NORTH);

        JPanel advisoryPanel = new JPanel(new BorderLayout(8,8));
        advisoryArea.setLineWrap(true);
        advisoryArea.setWrapStyleWord(true);
        advisoryPanel.add(new JScrollPane(advisoryArea), BorderLayout.CENTER);
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(copyPlain);
        advisoryPanel.add(south, BorderLayout.SOUTH);

        tabs.addTab("Translations", tablePanel);
        tabs.addTab("AdvisoryPL", advisoryPanel);

        add(tabs, BorderLayout.CENTER);

        model.setText(s.getModel());
        language.setText(s.getTargetLanguage());
        auto.setSelected(s.isAutoTranslate());
        skipReqResp.setSelected(s.isSkipReqResp());
        cloneIssues.setSelected(s.isCloneIntoIssues());
        baseUrl.setText(s.getBaseUrl());
        path.setText(s.getCompletionsPath());
        apiHdr.setText(s.getApiKeyHeader());
        apiHdrPrefix.setText(s.getApiKeyHeaderValuePrefix());
        prompt.setText(s.getCustomPrompt());

        save.addActionListener(e -> {
            s.setApiKeyMem(apiKey.getText());
            s.setModel(model.getText());
            s.setTargetLanguage(language.getText());
            s.setAutoTranslate(auto.isSelected());
            s.setSkipReqResp(skipReqResp.isSelected());
            s.setCloneIntoIssues(cloneIssues.isSelected());
            s.setBaseUrl(baseUrl.getText());
            s.setCompletionsPath(path.getText());
            s.setApiKeyHeader(apiHdr.getText());
            s.setApiKeyHeaderValuePrefix(apiHdrPrefix.getText());
            s.setCustomPrompt(prompt.getText());
            onSaveCb.run();
        });
        test.addActionListener(e -> onTestCb.run());
        copyPlain.addActionListener(e -> {
            String txt = getAdvisoryText();
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(txt == null ? "" : txt), null);
        });
    }

    void onSave(Runnable r) { this.onSaveCb = r; }
    void onTest(Runnable r) { this.onTestCb = r; }
    void addRow(String origin, String translated) { tableModel.addRow(new Object[]{origin, translated}); }
    void setAdvisoryText(String t) { advisoryArea.setText(t == null ? "" : t); }
    String getAdvisoryText() { return advisoryArea.getText(); }
}
