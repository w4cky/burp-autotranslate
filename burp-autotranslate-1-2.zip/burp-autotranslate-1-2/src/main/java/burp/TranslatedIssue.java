package burp;

import java.net.URL;

public class TranslatedIssue implements IScanIssue {
    private final IScanIssue base;
    private final String pl;

    public TranslatedIssue(IScanIssue base, String pl) {
        this.base = base;
        this.pl = pl == null ? "" : pl;
    }

    // Core identifiers
    @Override public URL getUrl() { return base.getUrl(); }
    @Override public String getIssueName() { return "[PL] " + base.getIssueName(); }
    @Override public int getIssueType() { return base.getIssueType(); }
    @Override public String getSeverity() { return base.getSeverity(); }
    @Override public String getConfidence() { return base.getConfidence(); }

    // Older API compatibility (some Burp versions require these on IScanIssue)
    @Override public String getHost() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getHost() != null) return svc.getHost();
            URL u = getUrl();
            return u != null ? u.getHost() : "unknown";
        } catch (Throwable t) { return "unknown"; }
    }
    @Override public int getPort() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getPort() > 0) return svc.getPort();
            URL u = getUrl();
            if (u != null && u.getPort() > 0) return u.getPort();
            return "https".equalsIgnoreCase(getProtocol()) ? 443 : 80;
        } catch (Throwable t) { return 80; }
    }
    @Override public String getProtocol() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getProtocol() != null) return svc.getProtocol();
            URL u = getUrl();
            return u != null && u.getProtocol() != null ? u.getProtocol() : "http";
        } catch (Throwable t) { return "http"; }
    }

    // Advisory text (Polish)
    @Override public String getIssueBackground() { return pl; }
    @Override public String getRemediationBackground() { return base.getRemediationBackground(); }

    @Override public String getIssueDetail() { return pl; }
    @Override public String getRemediationDetail() { return base.getRemediationDetail(); }

    // Messages / service
    @Override public IHttpRequestResponse[] getHttpMessages() { return base.getHttpMessages(); }
    @Override public IHttpService getHttpService() { return base.getHttpService(); }
}
