package burp;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.io.IOException;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.*;

class TranslationService {
    private final Settings settings;
    private final IBurpExtenderCallbacks callbacks;
    private final OkHttpClient http;
    private final ExecutorService pool;

    TranslationService(Settings settings, IBurpExtenderCallbacks callbacks) {
        this.settings = settings;
        this.callbacks = callbacks;
        this.http = new OkHttpClient.Builder()
                .callTimeout(Duration.ofSeconds(60))
                .connectTimeout(Duration.ofSeconds(20))
                .readTimeout(Duration.ofSeconds(60))
                .build();
        this.pool = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "translate-worker");
            t.setDaemon(true);
            return t;
        });
    }

    public void translateAsync(String original, java.util.function.Consumer<String> onDone) {
        pool.submit(() -> {
            try {
                String t = translateBlocking(original);
                if (t != null) onDone.accept(t);
            } catch (Exception e) {
                callbacks.printError("Translate error: " + e);
            }
        });
    }

    public String translateBlocking(String original) throws Exception {
        String apiKey = settings.getApiKey();
        if (apiKey == null || apiKey.isEmpty()) throw new IllegalStateException("OpenAI API key not set");

        String prompt = settings.getCustomPrompt() + "\n\n---\nORIGINAL ADVISORY:\n\n" + original;

        JsonObject root = new JsonObject();
        root.addProperty("model", settings.getModel());
        root.addProperty("temperature", 0.2);

        JsonArray messages = new JsonArray();
        JsonObject sys = new JsonObject();
        sys.addProperty("role", "system");
        sys.addProperty("content", "You are a cybersecurity technical translator for Burp Suite advisories.");
        messages.add(sys);

        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", prompt);
        messages.add(user);
        root.add("messages", messages);

        RequestBody body = RequestBody.create(root.toString(), MediaType.parse("application/json"));
        Request req = new Request.Builder()
                .url(settings.getBaseUrl() + settings.getCompletionsPath())
                .header(settings.getApiKeyHeader(), settings.getApiKeyHeaderValuePrefix() + apiKey)
                .header("Content-Type", "application/json")
                .post(body)
                .build();

        try (Response resp = http.newCall(req).execute()) {
            if (resp.isSuccessful()) {
                String json = Objects.requireNonNull(resp.body()).string();
                JsonObject jo = JsonParser.parseString(json).getAsJsonObject();
                return jo.getAsJsonArray("choices").get(0).getAsJsonObject()
                        .getAsJsonObject("message").get("content").getAsString();
            }
            throw new IOException("OpenAI HTTP " + resp.code() + " - " + resp.message());
        }
    }
}
