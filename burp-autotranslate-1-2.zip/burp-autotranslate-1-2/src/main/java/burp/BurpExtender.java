package burp;

import burp.*;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class BurpExtender implements IBurpExtender, ITab, IScannerListener, IContextMenuFactory {

    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private Settings settings;
    private UiPanel ui;
    private TranslationService translator;

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();
        callbacks.setExtensionName("Auto-Translate PL (OpenAI)");

        this.settings = new Settings(callbacks);
        this.ui = new UiPanel(settings);
        this.translator = new TranslationService(settings, callbacks);

        ui.onSave(() -> callbacks.printOutput("[PL-Translate] Settings saved."));
        ui.onTest(() -> {
            String sample = "# Issue name: Reflected XSS\n\n**Issue description**: parameter `q` is reflected without encoding.\n\n**Remediation**: apply output encoding.";
            try {
                String translated = translator.translateBlocking(sample);
                if (translated == null || translated.isEmpty()) {
                    JOptionPane.showMessageDialog(getUiComponent(), "Empty translation (check API key?)", "Warn", JOptionPane.WARNING_MESSAGE);
                } else {
                    ui.addRow(sample, translated);
                    ui.setAdvisoryText(translated);
                    JOptionPane.showMessageDialog(getUiComponent(), "Test translation OK.");
                }
            } catch (Exception ex) {
                callbacks.printError("Test translation failed: " + ex);
                JOptionPane.showMessageDialog(getUiComponent(), "Test failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        callbacks.addSuiteTab(this);
        callbacks.registerScannerListener(this);
        callbacks.registerContextMenuFactory(this);

        callbacks.printOutput("[PL-Translate] Loaded. Configure API key/prompt in the PL Translate tab.");
    }

    @Override
    public void newScanIssue(IScanIssue issue) {
        if (!settings.isAutoTranslate()) return;
        String original = Helpers.formatIssue(issue, settings.isSkipReqResp());
        translator.translateAsync(original, pl -> SwingUtilities.invokeLater(() -> {
            ui.addRow(original, pl);
            ui.setAdvisoryText(pl);
            if (settings.isCloneIntoIssues()) {
                try { callbacks.addScanIssue(new TranslatedIssue(issue, pl)); }
                catch (Throwable t) { callbacks.printError("Failed to add [PL] clone: " + t); }
            }
        }));
    }

    @Override public String getTabCaption() { return "PL Translate"; }
    @Override public Component getUiComponent() { return ui; }

    @Override
    public List<JMenuItem> createMenuItems(IContextMenuInvocation invocation) {
        JMenuItem mi = new JMenuItem("Translate selected issue(s) → AdvisoryPL + [PL] clone");
        mi.addActionListener(e -> {
            try {
                IScanIssue[] issues = invocation.getSelectedIssues();
                if (issues == null || issues.length == 0) return;
                for (IScanIssue is : issues) newScanIssue(is);
            } catch (Throwable t) { callbacks.printError("Context translate failed: " + t); }
        });

        JMenuItem copy = new JMenuItem("Copy translated (plain text)");
        copy.addActionListener(e -> {
            String txt = ui.getAdvisoryText();
            if (txt == null) return;
            Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(txt), null);
            callbacks.printOutput("[PL-Translate] Copied translation as plain text.");
        });

        return java.util.Arrays.asList(mi, copy);
    }
}
