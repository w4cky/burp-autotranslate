package burp;

import burp.*;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class BurpExtender implements IBurpExtender, ITab, IScannerListener, IContextMenuFactory {

    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private Settings settings;
    private UiPanel ui;
    private TranslationService translator;

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();
        callbacks.setExtensionName("Auto-Translate PL (OpenAI)");

        this.settings = new Settings(callbacks);
        this.ui = new UiPanel(settings);
        this.translator = new TranslationService(settings, callbacks);

        ui.onSave(new Runnable(){ public void run(){ callbacks.printOutput("[PL-Translate] Settings saved."); }});
        ui.onTest(new Runnable(){ public void run(){
            String sample = "# Robots.txt file\n\n**Issue description**: The robots.txt file can be abused to map private content.\n\n**Remediation**: Review robots.txt for sensitive paths.";
            try {
                String translated = translator.translateBlocking(sample);
                String[] split = Helpers.splitSections(translated);
                ui.addRow(sample, split[1]); // detail
                ui.setAdvisoryText(split[1]);
                JOptionPane.showMessageDialog(getUiComponent(), "Test translation OK.");
            } catch (Exception ex) {
                callbacks.printError("Test translation failed: " + ex);
                JOptionPane.showMessageDialog(getUiComponent(), "Test failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }});

        callbacks.addSuiteTab(this);
        callbacks.registerScannerListener(this);
        callbacks.registerContextMenuFactory(this);

        callbacks.printOutput("[PL-Translate] Loaded. Configure API key/prompt in the PL Translate tab.");
    }

    @Override
    public void newScanIssue(IScanIssue issue) {
        String nm = issue.getIssueName();
        if (nm != null && nm.trim().startsWith("[PL]")) return;

        if (!settings.isAutoTranslate()) return;
        String original = Helpers.formatIssue(issue, settings.isSkipReqResp());
        translator.translateAsync(original, new java.util.function.Consumer<String>() {
            @Override public void accept(String pl) {
                SwingUtilities.invokeLater(new Runnable(){ public void run(){
                    String[] split = Helpers.splitSections(pl);
                    ui.addRow(original, split[1]);
                    ui.setAdvisoryText(split[1]);
                    if (settings.isCloneIntoIssues()) {
                        try {
                            String plName = "[PL] " + issue.getIssueName();
                            IScanIssue[] existing = callbacks.getScanIssues(issue.getUrl() == null ? null : issue.getUrl().toString());
                            boolean found = false;
                            if (existing != null) {
                                for (IScanIssue ex : existing) {
                                    if (plName.equals(ex.getIssueName())) { found = true; break; }
                                }
                            }
                            if (!found) callbacks.addScanIssue(new TranslatedIssue(issue, split[1], split[0], split[2]));
                        } catch (Throwable t) { callbacks.printError("Failed to add [PL] clone: " + t); }
                    }
                }});
            }
        });
    }

    @Override public String getTabCaption() { return "PL Translate"; }
    @Override public Component getUiComponent() { return ui; }

    @Override
    public List<JMenuItem> createMenuItems(IContextMenuInvocation invocation) {
        JMenuItem mi = new JMenuItem("Translate selected issue(s) → AdvisoryPL + [PL] clone");
        mi.addActionListener(e -> {
            try {
                IScanIssue[] issues = invocation.getSelectedIssues();
                if (issues == null || issues.length == 0) return;
                for (IScanIssue is : issues) newScanIssue(is);
            } catch (Throwable t) { callbacks.printError("Context translate failed: " + t); }
        });

        JMenuItem copy = new JMenuItem("Copy translated (plain text)");
        copy.addActionListener(e -> {
            String txt = ui.getAdvisoryText();
            if (txt == null) return;
            Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(txt), null);
            callbacks.printOutput("[PL-Translate] Copied translation as plain text.");
        });

        return java.util.Arrays.asList(mi, copy);
    }
}
