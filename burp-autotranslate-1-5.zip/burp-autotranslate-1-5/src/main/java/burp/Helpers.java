package burp;

import java.util.Locale;

public class Helpers {
    public static String formatIssue(IScanIssue i, boolean skipReqResp) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(n(i.getIssueName())).append("\n\n");
        if (i.getUrl() != null) sb.append("**URL**: ").append(i.getUrl()).append("\n\n");
        String det = n(i.getIssueDetail());
        String rem = n(i.getRemediationDetail());
        String bg  = n(i.getIssueBackground());

        if (!det.isEmpty()) sb.append("**Issue description**:\n").append(det).append("\n\n");
        if (!rem.isEmpty()) sb.append("**Remediation**:\n").append(rem).append("\n\n");
        if (!bg.isEmpty())  sb.append("**Background**:\n").append(bg).append("\n\n");
        return sb.toString();
    }
    private static String n(String s) { return s == null ? "" : s; }

    public static String[] splitSections(String md) {
        if (md == null) return new String[]{"", "", ""};
        String text = md.replace("\r", "");
        String lower = text.toLowerCase(Locale.ROOT);

        String bg = section(text, lower, new String[]{"**tło**", "### tło", "background"});
        String opis = section(text, lower, new String[]{"**opis**", "### opis", "opis problemu", "issue description", "details", "szczegóły"});
        String name = nameLine(text, lower);
        String rem = section(text, lower, new String[]{"**remediacja**", "### remediacja", "remediation", "zalecenia"});
        String refs = section(text, lower, new String[]{"**odniesienia**", "### odniesienia", "references"});
        String asvs = section(text, lower, new String[]{"**mapowanie asvs**", "### mapowanie asvs", "asvs mapping"});

        StringBuilder detail = new StringBuilder();
        if (!isEmpty(name)) detail.append("**Nazwa podatności:** ").append(name.trim()).append("\n\n");
        if (!isEmpty(opis)) detail.append("**Opis**\n").append(opis.trim()).append("\n\n");
        if (!isEmpty(refs)) detail.append("**Odniesienia**\n").append(refs.trim()).append("\n\n");
        if (!isEmpty(asvs)) detail.append("**Mapowanie ASVS**\n").append(asvs.trim()).append("\n\n");

        if (detail.length() == 0) detail.append(text.trim());
        return new String[]{bg.trim(), detail.toString().trim(), rem.trim()};
    }

    private static boolean isEmpty(String s) { return s == null || s.trim().isEmpty(); }

    private static String nameLine(String text, String lower) {
        String[] markers = new String[]{"**nazwa podatności:**", "**nazwa problemu:**"};
        for (String m : markers) {
            int idx = lower.indexOf(m);
            if (idx >= 0) {
                int lineEnd = lower.indexOf("\n", idx);
                if (lineEnd < 0) lineEnd = lower.length();
                String line = text.substring(idx, lineEnd);
                String header = line.substring(0, Math.min(line.length(), m.length()));
                String rest = line.substring(header.length());
                return rest.trim();
            }
        }
        return "";
    }

    private static String section(String text, String lower, String[] headers) {
        int start = -1;
        String foundHeader = null;
        for (String h : headers) {
            int i = lower.indexOf(h);
            if (i >= 0 && (start < 0 || i < start)) { start = i; foundHeader = h; }
        }
        if (start < 0) return "";
        int lineEnd = lower.indexOf("\n", start);
        if (lineEnd < 0) lineEnd = lower.length();
        int contentStart = lineEnd + 1;

        int next = Integer.MAX_VALUE;
        String[] all = new String[] {
            "**tło**","### tło","background",
            "**opis**","### opis","opis problemu","issue description","details","szczegóły",
            "**remediacja**","### remediacja","remediation","zalecenia",
            "**odniesienia**","### odniesienia","references",
            "**mapowanie asvs**","### mapowanie asvs","asvs mapping",
            "**nazwa podatności:**","**nazwa problemu:**"
        };
        for (String h : all) {
            if (h.equals(foundHeader)) continue;
            int i = lower.indexOf(h, contentStart);
            if (i >= 0 && i < next) next = i;
        }
        if (next == Integer.MAX_VALUE) next = lower.length();
        return text.substring(contentStart, next).trim();
    }
}
