package burp;

import java.net.URL;

public class TranslatedIssue implements IScanIssue {
    private final IScanIssue base;
    private final String detailPl;
    private final String backgroundPl;
    private final String remediationPl;

    public TranslatedIssue(IScanIssue base, String detailPl, String backgroundPl, String remediationPl) {
        this.base = base;
        this.detailPl = detailPl == null ? "" : detailPl;
        this.backgroundPl = backgroundPl == null ? "" : backgroundPl;
        this.remediationPl = remediationPl == null ? "" : remediationPl;
    }

    @Override public URL getUrl() { return base.getUrl(); }
    @Override public String getIssueName() {
        String nm = base.getIssueName();
        if (nm != null && nm.trim().startsWith("[PL]")) return nm;
        return "[PL] " + nm;
    }
    @Override public int getIssueType() { return base.getIssueType(); }
    @Override public String getSeverity() { return base.getSeverity(); }
    @Override public String getConfidence() { return base.getConfidence(); }

    @Override public String getHost() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getHost() != null) return svc.getHost();
            URL u = getUrl();
            return u != null ? u.getHost() : "unknown";
        } catch (Throwable t) { return "unknown"; }
    }
    @Override public int getPort() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getPort() > 0) return svc.getPort();
            URL u = getUrl();
            if (u != null && u.getPort() > 0) return u.getPort();
            return "https".equalsIgnoreCase(getProtocol()) ? 443 : 80;
        } catch (Throwable t) { return 80; }
    }
    @Override public String getProtocol() {
        try {
            IHttpService svc = getHttpService();
            if (svc != null && svc.getProtocol() != null) return svc.getProtocol();
            URL u = getUrl();
            return u != null && u.getProtocol() != null ? u.getProtocol() : "http";
        } catch (Throwable t) { return "http"; }
    }

    @Override public String getIssueBackground() { return backgroundPl; }
    @Override public String getRemediationBackground() { return base.getRemediationBackground(); }

    @Override public String getIssueDetail() { return detailPl; }
    @Override public String getRemediationDetail() { return remediationPl.isEmpty() ? base.getRemediationDetail() : remediationPl; }

    @Override public IHttpRequestResponse[] getHttpMessages() { return base.getHttpMessages(); }
    @Override public IHttpService getHttpService() { return base.getHttpService(); }
}
