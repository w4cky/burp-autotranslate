# Burp Auto-Translate PL (1.2.4)

Build:
    mvn clean package -DskipTests -q

Load in Burp:
    target/burp-autotranslate-pl-1.2.4-fat.jar

Notes:
- Java 11 compatible (no text blocks).
- Polish Advisory sections with bold headers.
- Avoids [PL][PL] duplicates and duplicate clones per URL.
- Plain-text copying from AdvisoryPL tab or context menu.
